# 2 Touch Academy Demo

Working mobile-first web app prototype for a soccer player development platform.

## Features
- Coach dashboard
- Player roster and profiles
- Individual development goals
- Coach notes
- Drill library
- Working Start / Stop / Reset stopwatch
- Three assessment attempts
- Automatic best-time selection
- Local browser storage for saved results
- Progress charts

## GitHub Pages
Enable GitHub Pages from the repository settings and use the `main` branch / root folder.
